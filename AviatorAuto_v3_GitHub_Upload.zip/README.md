# Aviator Auto Analyzer 3.0

A simpler web-connected Android analyzer.

- Opens the Betway website inside the app.
- Lets the user log in normally; the app does not store or request Betway credentials.
- Polls the visible webpage text for Aviator-style multiplier results when the page exposes them as text.
- Stores up to 5,000 locally collected rounds.
- Shows descriptive statistics and historical frequencies.
- Manual round entry remains available.
- No automatic betting or bet placement.
- No Android Accessibility Service is required for this web mode.

Important: automatic capture depends on what the Betway webpage exposes to the WebView. If Aviator renders results only in a canvas, protected frame, or other inaccessible layer, the app cannot reliably capture them this way. That is a site-implementation limitation, not a screen-reader setting.

The statistical signal is descriptive and does not guarantee the next multiplier.
