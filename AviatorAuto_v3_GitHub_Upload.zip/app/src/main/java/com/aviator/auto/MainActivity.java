package com.aviator.auto;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.view.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private LinearLayout root, statsPanel;
    private TextView connection, stats, signal, history;
    private WebView web;
    private Handler handler = new Handler();
    private boolean connected = false;
    private String lastPageSignature = "";
    private static final Pattern MULT = Pattern.compile("(?<![0-9.])([1-9][0-9]{0,5}(?:\\.[0-9]{1,3})?)\\s*[xX×]");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
        refresh();
    }

    private TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(0xFF202124);
        t.setPadding(14, 8, 14, 8);
        return t;
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F5F5);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(8, 6, 8, 2);

        TextView title = tv("✈ Aviator Auto Analyzer 3.0", 20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Button connect = btn("CONNECT");
        connect.setOnClickListener(v -> connectToBetway());
        bar.addView(connect, new LinearLayout.LayoutParams(-2, -2));
        root.addView(bar);

        connection = tv("Not connected", 14);
        connection.setTextColor(0xFF666666);
        root.addView(connection);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        web.getSettings().setSupportMultipleWindows(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                connection.setText("Connected page: " + url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                connected = true;
                connection.setText("Connected • watching Aviator round data");
                startPagePolling();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        web.addJavascriptInterface(new PageBridge(), "AviatorBridge");

        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));

        statsPanel = new LinearLayout(this);
        statsPanel.setOrientation(LinearLayout.VERTICAL);
        statsPanel.setPadding(10, 4, 10, 4);
        statsPanel.setBackgroundColor(0xFFECECEC);

        signal = tv("Statistical range: —\nConfidence: NO DATA", 16);
        signal.setGravity(Gravity.CENTER);
        statsPanel.addView(signal);

        stats = tv("Rounds: 0\nAverage: 0.00x | Median: 0.00x", 13);
        statsPanel.addView(stats);

        root.addView(statsPanel, new LinearLayout.LayoutParams(-1, -2));

        Button manual = btn("ADD ROUNDS MANUALLY");
        manual.setOnClickListener(v -> showManualEntry());
        root.addView(manual);

        setContentView(root);

        connectToBetway();
    }

    private void connectToBetway() {
        connection.setText("Opening Betway…");
        web.loadUrl("https://www.betway.com/");
    }

    private void startPagePolling() {
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (web != null) {
                    web.evaluateJavascript(
                        "(function(){return document.body?document.body.innerText:'';})()",
                        value -> {
                            if (value != null) {
                                String text = value;
                                if (text.startsWith("\"") && text.endsWith("\"")) {
                                    text = text.substring(1, text.length()-1)
                                        .replace("\\n", "\n").replace("\\\"", "\"")
                                        .replace("\\\\", "\\");
                                }
                                processPageText(text);
                            }
                        }
                    );
                }
                handler.postDelayed(this, 1800);
            }
        }, 1000);
    }

    private void processPageText(String text) {
        String low = text.toLowerCase(Locale.US);
        if (!(low.contains("aviator") || low.contains("round"))) return;

        Matcher m = MULT.matcher(text);
        ArrayList<Double> vals = new ArrayList<>();
        while (m.find() && vals.size() < 150) {
            try {
                double x = Double.parseDouble(m.group(1));
                if (x >= 1.0 && x < 100000) vals.add(x);
            } catch (Exception ignored) {}
        }
        if (vals.isEmpty()) return;

        StringBuilder sig = new StringBuilder();
        for (double x : vals) sig.append(String.format(Locale.US, "%.3f,", x));
        String signature = sig.toString();
        if (signature.equals(lastPageSignature)) return;
        lastPageSignature = signature;

        ArrayList<Double> hist = load();
        if (hist.isEmpty()) {
            for (int i = vals.size() - 1; i >= 0; i--) hist.add(vals.get(i));
        } else {
            double newest = vals.get(0);
            if (Math.abs(hist.get(hist.size()-1) - newest) > 0.0001) hist.add(newest);
        }
        if (hist.size() > 5000)
            hist = new ArrayList<>(hist.subList(hist.size()-5000, hist.size()));
        save(hist);
        refresh();
    }

    private class PageBridge {
        @JavascriptInterface public void pageText(String text) {
            processPageText(text);
        }
    }

    private ArrayList<Double> load() {
        ArrayList<Double> a = new ArrayList<>();
        String s = getSharedPreferences("data", MODE_PRIVATE).getString("history", "");
        if (s.isEmpty()) return a;
        for (String p : s.split(",")) {
            try {
                double x = Double.parseDouble(p);
                if (x >= 1 && x < 100000) a.add(x);
            } catch (Exception ignored) {}
        }
        return a;
    }

    private void save(ArrayList<Double> a) {
        StringBuilder s = new StringBuilder();
        for (double x : a) {
            if (s.length() > 0) s.append(',');
            s.append(String.format(Locale.US, "%.3f", x));
        }
        getSharedPreferences("data", MODE_PRIVATE).edit().putString("history", s.toString()).apply();
    }

    private void showManualEntry() {
        EditText input = new EditText(this);
        input.setHint("1.12, 2.35, 1.04");
        new android.app.AlertDialog.Builder(this)
            .setTitle("Add Aviator rounds")
            .setView(input)
            .setPositiveButton("ADD", (d, w) -> {
                addManual(input.getText().toString());
                refresh();
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    private void addManual(String raw) {
        ArrayList<Double> a = load();
        for (String p : raw.split("[\\s,;]+")) {
            try {
                double x = Double.parseDouble(p.replace("x","").replace("X",""));
                if (x >= 1 && x < 100000) a.add(x);
            } catch (Exception ignored) {}
        }
        if (a.size() > 5000) a = new ArrayList<>(a.subList(a.size()-5000, a.size()));
        save(a);
    }

    private void refresh() {
        ArrayList<Double> a = load();
        PredictionEngine.Result r = PredictionEngine.analyze(a);
        stats.setText(String.format(Locale.US,
            "Rounds: %d   Average: %.2fx   Median: %.2fx\n≤1.20x: %.1f%%   ≥2x: %.1f%%   ≥5x: %.1f%%",
            r.n, r.avg, r.median, r.lowPct, r.p20, r.p50));
        signal.setText("Statistical range: " + r.range + "\nConfidence: " + r.confidence);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
