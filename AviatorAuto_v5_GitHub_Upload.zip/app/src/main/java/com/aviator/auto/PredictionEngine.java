package com.aviator.auto;

import java.util.*;

/** Descriptive/statistical signal engine. It does not claim deterministic prediction. */
public final class PredictionEngine {
    private PredictionEngine() {}
    public static final class Result {
        public final int n;
        public final double avg, median, lowPct, p15, p20, p30, p50, weightedMedian;
        public final String range, confidence, note;
        Result(int n,double avg,double median,double lowPct,double p15,double p20,double p30,double p50,double wm,String range,String confidence,String note){
            this.n=n;this.avg=avg;this.median=median;this.lowPct=lowPct;this.p15=p15;this.p20=p20;this.p30=p30;this.p50=p50;this.weightedMedian=wm;this.range=range;this.confidence=confidence;this.note=note;
        }
    }
    public static Result analyze(List<Double> source) {
        int n=source.size();
        if(n==0) return new Result(0,0,0,0,0,0,0,0,0,"—","NO DATA","Add rounds");
        ArrayList<Double> a=new ArrayList<>(source);
        double sum=0; int low=0; for(double x:a){sum+=x;if(x<=1.20)low++;}
        Collections.sort(a); double med=median(a), avg=sum/n;
        int window=Math.min(n,100); List<Double> r=source.subList(n-window,n);
        double p15=reachPct(r,1.5), p20=reachPct(r,2.0), p30=reachPct(r,3.0), p50=reachPct(r,5.0);
        double wm=weightedMedian(r);
        String range = wm<1.35?"~1.00–1.35×":wm<1.75?"~1.20–1.75×":wm<2.50?"~1.50–2.50×":wm<4?"~2.00–4.00×":"~3.00×+";
        double stability=Math.abs(p20-50); String conf=n<30?"LOW":(n<100?"MEDIUM":"DESCRIPTIVE");
        String note = n<100 ? "More rounds are needed for a meaningful backtest." : "Signal is descriptive; independent rounds can change without warning.";
        return new Result(n,avg,med,low*100.0/n,p15,p20,p30,p50,wm,range,conf,note);
    }
    private static double reachPct(List<Double> a,double t){if(a.isEmpty())return 0;int c=0;for(double x:a)if(x>=t)c++;return c*100.0/a.size();}
    private static double median(List<Double> a){int m=a.size()/2;return a.size()%2==1?a.get(m):(a.get(m-1)+a.get(m))/2.0;}
    private static double weightedMedian(List<Double> a){if(a.isEmpty())return 0; ArrayList<Integer> idx=new ArrayList<>();for(int i=0;i<a.size();i++)idx.add(i); idx.sort((i,j)->Double.compare(a.get(i),a.get(j)));double total=a.size()*(a.size()+1)/2.0,acc=0;for(int k:idx){int age=k+1;acc+=age;if(acc>=total/2.0)return a.get(k);}return a.get(a.size()-1);}
}
