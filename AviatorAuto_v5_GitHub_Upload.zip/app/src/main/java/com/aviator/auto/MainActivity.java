package com.aviator.auto;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private LinearLayout root, statsPanel;
    private TextView connection, stats, signal;
    private WebView web;
    private Handler handler = new Handler();
    private boolean connected = false;
    private String lastPageSignature = "";
    private String lastOcrSignature = "";
    private boolean ocrBusy = false;
    private int RED = 0xFFF31F2F;
    private int BG = 0xFF0B0C0F;
    private int PANEL = 0xFF14161B;
    private int CARD = 0xFF1A1D23;
    private int WHITE = 0xFFFFFFFF;
    private int MUTED = 0xFFA7ADB8;
    private com.google.mlkit.vision.text.TextRecognizer recognizer;

    // Accept common multiplier formats such as 1.24x, 2x, 10.50 X and OCR variants.
    private static final Pattern MULT = Pattern.compile(
        "(?<![0-9.])([1-9][0-9]{0,5}(?:[.,][0-9]{1,3})?)\\s*[xX×](?![a-zA-Z])"
    );

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        showSplash();
    }

    private TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(WHITE);
        t.setPadding(14, 8, 14, 8);
        return t;
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(28, 28, 28, 28);
        splash.setBackgroundColor(BG);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.aviator.auto.R.drawable.ic_plane_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        splash.addView(logo, new LinearLayout.LayoutParams(150, 150));

        TextView name = tv("Aviator Auto Analyzer", 27);
        name.setTextColor(WHITE);
        name.setGravity(Gravity.CENTER);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        splash.addView(name, new LinearLayout.LayoutParams(-1, -2));

        TextView tagline = tv("Analyze. Predict. Profit.", 15);
        tagline.setTextColor(MUTED);
        tagline.setGravity(Gravity.CENTER);
        splash.addView(tagline, new LinearLayout.LayoutParams(-1, -2));

        TextView plane = tv("Plane to Profit.", 14);
        plane.setTextColor(RED);
        plane.setGravity(Gravity.CENTER);
        splash.addView(plane, new LinearLayout.LayoutParams(-1, -2));

        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        splash.addView(progress, new LinearLayout.LayoutParams(44, 44));

        TextView loading = tv("Initializing engines…", 13);
        loading.setTextColor(MUTED);
        loading.setGravity(Gravity.CENTER);
        splash.addView(loading, new LinearLayout.LayoutParams(-1, -2));

        setContentView(splash);
        new Handler().postDelayed(() -> { build(); refresh(); }, 1300);
    }

    private void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(8, 6, 8, 2);

        TextView title = tv("✈  Aviator Auto Analyzer 4.0", 20);
        title.setTextColor(WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Button connect = btn("CONNECT TO BETWAY");
        connect.setTextColor(WHITE);
        connect.setBackgroundColor(RED);
        connect.setOnClickListener(v -> connectToBetway());
        bar.addView(connect, new LinearLayout.LayoutParams(-2, -2));
        root.addView(bar);

        connection = tv("Not connected", 14);
        connection.setTextColor(MUTED);
        root.addView(connection);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        web.getSettings().setSupportMultipleWindows(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                connection.setText("Loading: " + url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                connected = true;
                connection.setText("Connected • DOM + visual reader active");
                startPolling();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        web.addJavascriptInterface(new PageBridge(), "AviatorBridge");
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));

        statsPanel = new LinearLayout(this);
        statsPanel.setOrientation(LinearLayout.VERTICAL);
        statsPanel.setPadding(10, 4, 10, 4);
        statsPanel.setBackgroundColor(PANEL);

        signal = tv("Statistical range: —\nConfidence: NO DATA", 16);
        signal.setTextColor(WHITE);
        signal.setGravity(Gravity.CENTER);
        statsPanel.addView(signal);

        stats = tv("Rounds: 0\nAverage: 0.00x | Median: 0.00x", 13);
        stats.setTextColor(MUTED);
        statsPanel.addView(stats);
        root.addView(statsPanel, new LinearLayout.LayoutParams(-1, -2));

        Button manual = btn("ADD ROUNDS MANUALLY");
        manual.setTextColor(WHITE);
        manual.setBackgroundColor(CARD);
        manual.setOnClickListener(v -> showManualEntry());
        root.addView(manual);

        setContentView(root);
        connectToBetway();
    }

    private void connectToBetway() {
        connection.setText("Opening Betway…");
        web.loadUrl("https://www.betway.com/");
    }

    private void startPolling() {
        handler.removeCallbacksAndMessages(null);

        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (web != null && connected) readDom();
                handler.postDelayed(this, 1800);
            }
        }, 1000);

        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (web != null && connected) captureAndOcr();
                handler.postDelayed(this, 3000);
            }
        }, 2500);
    }

    private void readDom() {
        String script =
            "(function(){" +
            "function collect(root,out){" +
            " if(!root)return;" +
            " try{if(root.body)out.push(root.body.innerText||'');}catch(e){}" +
            " var els=[];" +
            " try{els=root.querySelectorAll('*');}catch(e){return;}" +
            " for(var i=0;i<els.length;i++){" +
            "   var e=els[i];" +
            "   try{if(e.shadowRoot)collect(e.shadowRoot,out);}catch(x){}" +
            "   try{if(e.tagName==='IFRAME'&&e.contentDocument)collect(e.contentDocument,out);}catch(x){}" +
            " }" +
            "}" +
            "var a=[];collect(document,a);return a.join('\\n');" +
            "})()";

        web.evaluateJavascript(script, value -> {
            if (value != null) processPageText(unescapeJs(value), "DOM");
        });
    }

    private String unescapeJs(String value) {
        if (value.startsWith("\"") && value.endsWith("\"")) {
            value = value.substring(1, value.length() - 1);
        }
        return value.replace("\\n", "\n")
            .replace("\\r", "\r")
            .replace("\\\"", "\"")
            .replace("\\\\", "\\");
    }

    private void captureAndOcr() {
        if (ocrBusy || web.getWidth() <= 0 || web.getHeight() <= 0) return;
        ocrBusy = true;

        Bitmap bitmap = Bitmap.createBitmap(web.getWidth(), web.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        web.draw(canvas);

        InputImage image = InputImage.fromBitmap(bitmap, 0);
        recognizer.process(image)
            .addOnSuccessListener(result -> {
                String text = result.getText();
                processPageText(text, "Visual OCR");
            })
            .addOnCompleteListener(task -> {
                bitmap.recycle();
                ocrBusy = false;
            });
    }

    private void processPageText(String text, String source) {
        if (text == null || text.trim().isEmpty()) return;

        String low = text.toLowerCase(Locale.US);
        if (!(low.contains("aviator") || low.contains("round") || low.contains("multiplier"))) return;

        Matcher m = MULT.matcher(text);
        ArrayList<Double> vals = new ArrayList<>();
        while (m.find() && vals.size() < 150) {
            try {
                double x = Double.parseDouble(m.group(1).replace(',', '.'));
                if (x >= 1.0 && x < 100000) vals.add(x);
            } catch (Exception ignored) {}
        }
        if (vals.isEmpty()) return;

        StringBuilder sig = new StringBuilder();
        for (double x : vals) sig.append(String.format(Locale.US, "%.3f,", x));
        String signature = sig.toString();

        if (source.equals("DOM")) {
            if (signature.equals(lastPageSignature)) return;
            lastPageSignature = signature;
        } else {
            if (signature.equals(lastOcrSignature)) return;
            lastOcrSignature = signature;
        }

        ArrayList<Double> hist = load();

        // Only add values that are not already the current tail.
        // This avoids repeatedly adding the same visible history from DOM/OCR.
        for (int i = vals.size() - 1; i >= 0; i--) {
            double x = vals.get(i);
            if (hist.isEmpty() || Math.abs(hist.get(hist.size() - 1) - x) > 0.0001) {
                hist.add(x);
            }
        }

        if (hist.size() > 5000)
            hist = new ArrayList<>(hist.subList(hist.size() - 5000, hist.size()));

        save(hist);
        connection.setText("Connected • data detected via " + source);
        refresh();
    }

    private class PageBridge {
        @JavascriptInterface public void pageText(String text) {
            processPageText(text, "Page");
        }
    }

    private ArrayList<Double> load() {
        ArrayList<Double> a = new ArrayList<>();
        String s = getSharedPreferences("data", MODE_PRIVATE).getString("history", "");
        if (s.isEmpty()) return a;
        for (String p : s.split(",")) {
            try {
                double x = Double.parseDouble(p);
                if (x >= 1 && x < 100000) a.add(x);
            } catch (Exception ignored) {}
        }
        return a;
    }

    private void save(ArrayList<Double> a) {
        StringBuilder s = new StringBuilder();
        for (double x : a) {
            if (s.length() > 0) s.append(',');
            s.append(String.format(Locale.US, "%.3f", x));
        }
        getSharedPreferences("data", MODE_PRIVATE).edit().putString("history", s.toString()).apply();
    }

    private void showManualEntry() {
        EditText input = new EditText(this);
        input.setHint("1.12, 2.35, 1.04");
        new android.app.AlertDialog.Builder(this)
            .setTitle("Add Aviator rounds")
            .setView(input)
            .setPositiveButton("ADD", (d, w) -> {
                addManual(input.getText().toString());
                refresh();
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    private void addManual(String raw) {
        ArrayList<Double> a = load();
        for (String p : raw.split("[\\s,;]+")) {
            try {
                double x = Double.parseDouble(p.replace("x","").replace("X",""));
                if (x >= 1 && x < 100000) a.add(x);
            } catch (Exception ignored) {}
        }
        if (a.size() > 5000) a = new ArrayList<>(a.subList(a.size()-5000, a.size()));
        save(a);
    }

    private void refresh() {
        ArrayList<Double> a = load();
        PredictionEngine.Result r = PredictionEngine.analyze(a);
        stats.setText(String.format(Locale.US,
            "Rounds: %d   Average: %.2fx   Median: %.2fx\n≤1.20x: %.1f%%   ≥2x: %.1f%%   ≥5x: %.1f%%",
            r.n, r.avg, r.median, r.lowPct, r.p20, r.p50));
        signal.setText("Statistical range: " + r.range + "\nConfidence: " + r.confidence);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.close();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
