package com.aviator.auto;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import android.widget.Toast;
import java.util.*;
import java.util.regex.*;

public class AviatorAccessibilityService extends AccessibilityService {
    public static volatile boolean running=false;
    public static volatile AviatorAccessibilityService instance;
    private static final Pattern MULT=Pattern.compile("(?<![0-9.])([0-9]{1,6}(?:\\.[0-9]{1,3})?)\\s*[xX×]");
    private final Handler handler=new Handler();
    private String lastScreenSignature="";
    private WindowManager wm; private TextView overlay; private boolean overlayShown=false;
    private final String[] allowedBrowsers={"com.android.chrome","com.huawei.browser","com.android.browser"};
    @Override public void onServiceConnected(){super.onServiceConnected();running=true;instance=this; if(canOverlay()) showOverlay();}
    @Override public void onDestroy(){running=false;instance=null;removeOverlay();super.onDestroy();}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        String pkg=e.getPackageName()==null?"":e.getPackageName().toString();
        if(!(pkg.toLowerCase(Locale.US).contains("betway")||Arrays.asList(allowedBrowsers).contains(pkg))) return;
        handler.removeCallbacksAndMessages(null); handler.postDelayed(this::scan,160);
    }
    private void scan(){
        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return;
        String text=treeText(root), low=text.toLowerCase(Locale.US);
        if(!low.contains("round history"))return;
        int pos=low.indexOf("round history"); String section=text.substring(pos);
        Matcher m=MULT.matcher(section); ArrayList<Double> vals=new ArrayList<>();
        while(m.find()&&vals.size()<100){try{double x=Double.parseDouble(m.group(1));if(x>=1&&x<100000)vals.add(x);}catch(Exception ignored){}}
        if(vals.isEmpty())return;
        StringBuilder sig=new StringBuilder();for(double x:vals)sig.append(String.format(Locale.US,"%.3f,",x));
        String signature=sig.toString(); if(signature.equals(lastScreenSignature)){updateOverlay();return;} lastScreenSignature=signature;
        android.content.SharedPreferences p=getSharedPreferences("data",MODE_PRIVATE);
        ArrayList<Double> hist=load(p.getString("history","")); boolean initialized=p.getBoolean("initialized",false);
        if(!initialized){for(int i=vals.size()-1;i>=0;i--)hist.add(vals.get(i));p.edit().putBoolean("initialized",true).apply();}
        else {double newest=vals.get(0);if(hist.isEmpty()||Math.abs(hist.get(hist.size()-1)-newest)>0.0001)hist.add(newest);}
        if(hist.size()>5000)hist=new ArrayList<>(hist.subList(hist.size()-5000,hist.size())); save(hist,p); updateOverlay();
        Toast.makeText(this,"Round added: "+String.format(Locale.US,"%.2fx",vals.get(0)),Toast.LENGTH_SHORT).show();
    }
    private ArrayList<Double> load(String s){ArrayList<Double>a=new ArrayList<>();if(s==null||s.isEmpty())return a;for(String q:s.split(","))try{double x=Double.parseDouble(q);if(x>=1&&x<100000)a.add(x);}catch(Exception ignored){}return a;}
    private void save(ArrayList<Double>a,android.content.SharedPreferences p){StringBuilder s=new StringBuilder();for(double x:a){if(s.length()>0)s.append(',');s.append(String.format(Locale.US,"%.3f",x));}p.edit().putString("history",s.toString()).apply();}
    private String treeText(AccessibilityNodeInfo n){StringBuilder b=new StringBuilder();walk(n,b);return b.toString();}
    private void walk(AccessibilityNodeInfo n,StringBuilder b){if(n==null)return;CharSequence t=n.getText();if(t!=null)b.append(t).append(' ');CharSequence d=n.getContentDescription();if(d!=null)b.append(d).append(' ');for(int i=0;i<n.getChildCount();i++)walk(n.getChild(i),b);}
    private boolean canOverlay(){return Settings.canDrawOverlays(this);}
    public void toggleOverlay(){if(overlayShown)removeOverlay();else if(canOverlay())showOverlay();}
    private void showOverlay(){if(overlayShown||!canOverlay())return;wm=(WindowManager)getSystemService(WINDOW_SERVICE);overlay=new TextView(this);overlay.setTextColor(0xFFFFFFFF);overlay.setTextSize(12);overlay.setPadding(16,10,16,10);overlay.setGravity(Gravity.CENTER);overlay.setBackgroundColor(0xE61A1B20);overlay.setText("AVIATOR\nWaiting for round data…");
        int type=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.END;lp.x=10;lp.y=80;try{wm.addView(overlay,lp);overlayShown=true;}catch(Exception ignored){}}
    private void removeOverlay(){if(!overlayShown||wm==null||overlay==null)return;try{wm.removeView(overlay);}catch(Exception ignored){}overlay=null;overlayShown=false;}
    private void updateOverlay(){if(!overlayShown||overlay==null)return;ArrayList<Double>a=load(getSharedPreferences("data",MODE_PRIVATE).getString("history",""));PredictionEngine.Result r=PredictionEngine.analyze(a);String txt="AVIATOR SIGNAL\n"+r.range+"\n2× reach: "+String.format(Locale.US,"%.0f%%",r.p20)+"\n5× reach: "+String.format(Locale.US,"%.0f%%",r.p50)+"\nConfidence: "+r.confidence+"\nNot a guaranteed prediction";overlay.setText(txt);}
    @Override public void onInterrupt(){running=false;}
}
