package com.aviator.auto;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView status, stats, signal, history; EditText input;
    int green=0xFF16A34A;
    @Override public void onCreate(Bundle b){super.onCreate(b);build();refresh();}
    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xFF202124);t.setPadding(18,12,18,12);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16);root.setBackgroundColor(0xFFF5F5F5);
        TextView title=tv("Aviator Auto Analyzer 2.0",24);title.setGravity(Gravity.CENTER);root.addView(title);
        status=tv("Automatic reader: OFF",16);root.addView(status);
        Button access=btn("1. Enable automatic screen reading");access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(access);
        Button overlay=btn("2. Enable floating prediction panel");overlay.setOnClickListener(v->openOverlaySettings());root.addView(overlay);
        signal=tv("Signal: waiting for rounds…",19);signal.setGravity(Gravity.CENTER);signal.setPadding(10,18,10,18);root.addView(signal);
        stats=tv("",15);root.addView(stats);
        TextView lab=tv("Add rounds manually (optional)",15);root.addView(lab);
        input=new EditText(this);input.setInputType(InputType.TYPE_CLASS_TEXT);input.setHint("1.12, 2.35, 1.04");root.addView(input);
        Button add=btn("Add rounds");add.setOnClickListener(v->{addManual(input.getText().toString());input.setText("");refresh();});root.addView(add);
        Button floatBtn=btn("Show / hide floating panel now");floatBtn.setOnClickListener(v->{if(AviatorAccessibilityService.instance!=null)AviatorAccessibilityService.instance.toggleOverlay();else Toast.makeText(this,"Enable Accessibility first.",Toast.LENGTH_SHORT).show();});root.addView(floatBtn);
        Button clear=btn("Clear local history");clear.setOnClickListener(v->{getSharedPreferences("data",MODE_PRIVATE).edit().clear().apply();refresh();});root.addView(clear);
        history=tv("",14);ScrollView sc=new ScrollView(this);sc.addView(history);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        TextView note=tv("Signal = statistical description of your history, not a guaranteed next multiplier. The app never places bets.",12);root.addView(note);
        setContentView(root);
    }
    void openOverlaySettings(){if(android.os.Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){try{startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));}}else{if(AviatorAccessibilityService.instance!=null)AviatorAccessibilityService.instance.toggleOverlay();}}
    ArrayList<Double> load(){ArrayList<Double>a=new ArrayList<>();String s=getSharedPreferences("data",MODE_PRIVATE).getString("history","");if(s.isEmpty())return a;for(String p:s.split(","))try{double x=Double.parseDouble(p);if(x>=1&&x<100000)a.add(x);}catch(Exception ignored){}return a;}
    void save(ArrayList<Double>a){StringBuilder s=new StringBuilder();for(double x:a){if(s.length()>0)s.append(',');s.append(String.format(Locale.US,"%.3f",x));}getSharedPreferences("data",MODE_PRIVATE).edit().putString("history",s.toString()).apply();}
    void addManual(String raw){ArrayList<Double>a=load();for(String p:raw.split("[\\s,;]+"))try{double x=Double.parseDouble(p.replace("x","").replace("X",""));if(x>=1&&x<100000)a.add(x);}catch(Exception ignored){}if(a.size()>5000)a=new ArrayList<>(a.subList(a.size()-5000,a.size()));save(a);}
    void refresh(){ArrayList<Double>a=load();PredictionEngine.Result r=PredictionEngine.analyze(a);stats.setText(String.format(Locale.US,"Rounds: %d\nAverage: %.2fx | Median: %.2fx\n≤1.20x: %.1f%%\nReach 1.5x: %.1f%%   2x: %.1f%%\nReach 3x: %.1f%%   5x: %.1f%%",r.n,r.avg,r.median,r.lowPct,r.p15,r.p20,r.p30,r.p50));signal.setText("Statistical range: "+r.range+"\nConfidence: "+r.confidence+"\n"+r.note);status.setText("Automatic reader: "+(AviatorAccessibilityService.running?"ON":"OFF")+" | Floating panel: "+(Settings.canDrawOverlays(this)?"AVAILABLE":"OFF"));StringBuilder s=new StringBuilder("Latest rounds:\n");int start=Math.max(0,a.size()-100);for(int i=a.size()-1;i>=start;i--){s.append(String.format(Locale.US,"%.2fx  ",a.get(i)));if((a.size()-i)%6==0)s.append('\n');}history.setText(s.toString());}
    @Override protected void onResume(){super.onResume();refresh();}
}
